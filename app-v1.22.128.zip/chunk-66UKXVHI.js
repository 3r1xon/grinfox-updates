var o={endpoint:"https://grinfox-notify.erixonconsoli.workers.dev"};export{o as a};
