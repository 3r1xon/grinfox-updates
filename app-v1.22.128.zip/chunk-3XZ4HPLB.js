import{a}from"./chunk-DWKSN5WW.js";import"./chunk-YDOXD4O3.js";export{a as startFocusVisible};
