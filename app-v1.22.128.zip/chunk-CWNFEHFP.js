import{a as r}from"./chunk-EO5RNFGC.js";var n=()=>{if(r!==void 0)return r.Capacitor};export{n as a};
